<!DOCTYPE html>
<html>
    <head>
        <title>Home - Pura Kencana Badminton Booking System</title>
        <link rel="stylesheet" type="text/css" href="css/home.css">
        <style>
            .img-container {
        text-align: center;
        
      }
        </style>
    </head>
    <body>
        <div class="container">
        <div class="col">
            <div class="col">
                <h1>ABOUT</h1>
                <P>We do an interview to get some information from pura kencana's uncle.
                    </P>
            </div>
        <div class="col">
            <div class="img-container">
              <img src="images/survey.jpeg" alt="Badminton" style="width:20%">
            </div>
            <div class="img-container">
              <img src="images/gelanggang.jpeg" alt="Forest" style="width:20%">
            </div>
        </div>
    </body>
</html>