<!DOCTYPE html>
<html>
    <head>
        <title>Homepage - Pura Kencana Badminton Booking System</title>
        <link rel="stylesheet" type="text/css" href="css/login.css">
        <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
    </head>
    <body>
        <div class="header">
            <div class="homepageContainer">
                <a href="login.php">Login</a>
            </div>
        </div>
        <div class="banner">
            <div class="homepageContainer">
            <div class="bannerHeader">
                <h1>PKB</h1>
                <p>Pura Kencana Badminton Booking System</p>
            </div>
            <p class="bannerAddress">No.1. Jalan Sisiran Pura Kencana 1A/1,
                Taman Genting Pura Kencana,
                83300, Sri Gading, Batu Pahat, Johor
                <p class="bannerTel">Tel	:	+607 - 455 8181</p>
                <p class="bannerFax">Fax	:	+607 - 455 7171</p>
               <p class="bannerEmail">Email	:	purakencana@genting.com</p>   
            <p class="bannerTagline">It's time to show your skill..
            </p>
            <div class="bannerIcon">
                <a href=""><i class="fa fa-apple"> </i></a>
                <a href=""><i class="fa fa-android"> </i></a>
                <a href=""><i class="fa fa-windows"> </i></a>
            </div>
        </div>
    </body>
       
</html>