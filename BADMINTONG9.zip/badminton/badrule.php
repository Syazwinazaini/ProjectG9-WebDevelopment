<!DOCTYPE html>
<html>
    <head>
        <title>Badminton</title>
        <link rel="stylesheet" type="text/css" href="css/login.css">
        <style>
            table {
              border-collapse: collapse;
              border-spacing: 0;
              width: 100%;
              border: 1px solid #ddd;
            }
            
            th, td {
              text-align: left;
              padding: 16px;
            }
            
            tr:nth-child(even) {
              background-color: #f2f2f2;
            }
            </style>
    </head>
    <body>
        <div id="dashboardMainContainer">
            <div class="dashboard_sidebar" id="dashboard_sidebar">
                <h3 class="dashboard_logo" id="dashboard_logo">PKB</h3>
                <div class="dashboard_sidebar_user">
                    <img src="images/abduh.jpeg" alt="user image." id="userImage" />
                    <span>Abduh</span>
                </div>
            <div class="dashboard_sidebar_menus">
                <ul class="dashboard_menu_lists">
                    <li class="menuActive">
                        <a href="badrule.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>BADMINTON RULE</a>
                    </li>
                    <li>
                        <a href="service.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>SERVICE SKILL</a>
                    </li>
                    <li>
                        <a href="iconbad.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>ICON BADMINTON</a>
                    </li>
                    <li>
                        <a href="booking.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>BOOKING</a>
                    </li>
                    <li>
                        <a href="feedback.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>FEEDBACK</a>
                    </li>
                    <li>
                        <a href="contact.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>CONTACT US</a>
                    </li>
                </ul>
            </div>
            </div>
        
        <div class="dashboard_content">
            <div class="dashboard_content_main">
                
                <video width="800" controls >
                <source src="video/movie.mp4" type=video/mp4>
                </video>
                            </div>
                    </div>
                
                
                  
            </div>
        </div>
        </div>
        </div>
       
    <script>
        var sideBarIsOpen = 'true' 

        toggleBtn.addEventListener( 'click', (event) => {
            event.preventDefault();

            if(sideBarIsOpen){
            dashboard_sidebar.style.width = '10%';
            dashboard_content_container.style.width = '90%';
            dashboard_logo.style.fontSize = '60px';
            userImage.style.width = '60px';

            menuIcons = document.getElementsByClassName('menuText');
            for(var i=0; i < menuIcons.length; i++){
                menuIcons[i].style.display = 'none';
            }
            document.getElementsByClassName('dashboard_menu_lists')[0].style.textAlign = 'center';
            sideBarIsOpen = false;
        }
        else{
            dashboard_sidebar.style.width = '20%';
            dashboard_content_container.style.width = '80%';
            dashboard_logo.style.fontSize = '80px';
            userImage.style.width = '80px';

            menuIcons = document.getElementsByClassName('menuText');
            for(var i=0; i < menuIcons.length; i++){
                menuIcons[i].style.display = 'inline-block';
            }
            document.getElementsByClassName('dashboard_menu_lists')[0].style.textAlign = 'normal';

        }
        sideBarIsOpen = true;
        });
    </script>
    </body>
       
</html>
<!--<!DOCTYPE html>
<html>
    <head>
        <title>BADMINTON RULE</title>
        <link rel="stylesheet" type="text/css" href="css/login.css">
        <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
    </head>
    <body>
        <video width="600" controls>
        <source src="video/rule.mp4" type="video/mp4">
    </video>
    </body>
</html>-->