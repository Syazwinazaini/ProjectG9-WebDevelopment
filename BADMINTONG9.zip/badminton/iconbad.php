<!DOCTYPE html>
<html>
    <head>
        <title>Badminton</title>
        <link rel="stylesheet" type="text/css" href="css/icon.css">
        <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
        <style>
            .container{
                background-color: #c0c0c0;
                
            }
            .center{
                display: block;
                margin-left: auto;
                margin-right: auto;
            }
            </style>
    </head>
    <body>
        <div id="dashboardMainContainer">
            <div class="dashboard_sidebar" id="dashboard_sidebar">
                <h3 class="dashboard_logo" id="dashboard_logo">PKB</h3>
                <div class="dashboard_sidebar_user">
                    <img src="images/abduh.jpeg" alt="user image." id="userImage" />
                    <span>Abduh</span>
                </div>
            <div class="dashboard_sidebar_menus">
                <ul class="dashboard_menu_lists">
                    <li class="menuActive">
                        <a href="badrule.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>BADMINTON RULE</a>
                    </li>
                    <li>
                        <a href="service.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>SERVICE SKILL</a>
                    </li>
                    <li>
                        <a href="iconbad.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>ICON BADMINTON</a>
                    </li>
                    <li>
                        <a href="booking.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>BOOKING</a>
                    </li>
                    <li>
                        <a href="feedback.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>FEEDBACK</a>
                    </li>
                    <li>
                        <a href="contact.php"><i class="fa fa-dashboard "></i> <span class="menuText"></span>CONTACT US</a>
                    </li>
                </ul>
            </div>
            </div>
        
        <div class="dashboard_content">
            <div class="dashboard_content_main">
                
                    <div class="container">
                    <div class="card">
                    <img src="images/chong.jpeg" alt="Basic" class="center">
                    <div class="intro">
                        <h1>LEE CHONG WEI</h1>
                        <p>For <span>About</span> Datuk Lee Chong Wei DB, DCSM, PJN, DSPN, AMN, JP, PhD is a Malaysian former badminton player. As a singles player, Lee was ranked first worldwide for 349 weeks, including a 199-week streak from 21 August 2008 to 14 June 2012.
            
                        </p>
                    </div>
                    </div>
                    <div class="card">
                        <img src="images/jia.jpg" alt="Basic" style="width: 15%" class="center">
                        <div class="intro" >
                            <h1>LEE ZI JIA</h1>
                            <p>For <span>About</span> Lee Zii Jia ASK is a Malaysian professional badminton player. He was the men's singles gold medalist at the 2019 SEA Games and won his first BWF Super 1000 title at the 2021 All England Open. Lee is the 2022 men's singles Asian champion, winning the title at the 2022 Badminton Asia Championships. 
            
                            </p>
                        </div>
                        </div>
                        
                            </div>
                    </div>
                
                
                  
            </div>
        </div>
        </div>
        </div>
       
    <script>
        var sideBarIsOpen = 'true' 

        toggleBtn.addEventListener( 'click', (event) => {
            event.preventDefault();

            if(sideBarIsOpen){
            dashboard_sidebar.style.width = '10%';
            dashboard_content_container.style.width = '90%';
            dashboard_logo.style.fontSize = '60px';
            userImage.style.width = '60px';

            menuIcons = document.getElementsByClassName('menuText');
            for(var i=0; i < menuIcons.length; i++){
                menuIcons[i].style.display = 'none';
            }
            document.getElementsByClassName('dashboard_menu_lists')[0].style.textAlign = 'center';
            sideBarIsOpen = false;
        }
        else{
            dashboard_sidebar.style.width = '20%';
            dashboard_content_container.style.width = '80%';
            dashboard_logo.style.fontSize = '80px';
            userImage.style.width = '80px';

            menuIcons = document.getElementsByClassName('menuText');
            for(var i=0; i < menuIcons.length; i++){
                menuIcons[i].style.display = 'inline-block';
            }
            document.getElementsByClassName('dashboard_menu_lists')[0].style.textAlign = 'normal';

        }
        sideBarIsOpen = true;
        });
    </script>
    </body>
       
</html>