<?php
    session_start();

    //re,ove all session variables
    session_unset();


    //destroy
    session_destroy();

?> 