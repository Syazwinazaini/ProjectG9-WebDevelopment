<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','badminton');

// get the post records

$name=$_POST['name'];
$customer_phone=$_POST['customer_phone'];
$date=$_POST['date'];
$hour=$_POST['hour'];


    

// database insert SQL code
$sql = "INSERT INTO `booking` ( `name`, `customer_phone`, `date`, `hour`) VALUES ('$name', '$customer_phone', '$date', '$hour')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Person Records Inserted";
}

?>