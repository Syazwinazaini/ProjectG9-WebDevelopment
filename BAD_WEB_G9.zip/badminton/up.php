<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','badminton');

// get the post records

$email=$_POST['email'];
$password=$_POST['password'];


    

// database insert SQL code
$sql = "INSERT INTO `sign` ( `email`, `password`) VALUES ('$email' ,'$password')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Person Records Inserted";
}

?>